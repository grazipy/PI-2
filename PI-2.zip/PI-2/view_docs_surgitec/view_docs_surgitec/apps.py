from django.apps import AppConfig

class ViewDocsSurgitecConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'view_docs_surgitec'
